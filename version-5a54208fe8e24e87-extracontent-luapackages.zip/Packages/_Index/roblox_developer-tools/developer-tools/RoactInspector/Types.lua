export type SerializedInstance = {
	id: number;
	name: string;
	className: string;
}

return {}