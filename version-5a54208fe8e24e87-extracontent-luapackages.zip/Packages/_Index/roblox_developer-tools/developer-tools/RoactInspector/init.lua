local RoactInspectorWorker = require(script.Classes.RoactInspectorWorker)

return RoactInspectorWorker