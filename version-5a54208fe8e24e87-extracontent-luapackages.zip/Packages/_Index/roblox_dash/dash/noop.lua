--[[
	A function which does nothing.

	Can be used to make it clear that a handler has no function.
]]
local function noop()

end

return noop