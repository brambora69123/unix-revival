return {
	AssetCard = require(script.Components.AssetCard),
}
