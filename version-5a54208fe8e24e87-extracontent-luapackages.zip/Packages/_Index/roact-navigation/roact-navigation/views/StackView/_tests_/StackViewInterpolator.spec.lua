return function()
	local StackViewInterpolator = require(script.Parent.Parent.StackViewInterpolator)

	itSKIP("should have its tests implemented", function()

	end)
end
