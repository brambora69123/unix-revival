-- Alias for Cryo.None
local Cryo = require(script.Parent.Parent.Cryo)
return Cryo.None