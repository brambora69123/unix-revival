return function()
	return settings():GetFFlag("UseDateTimeType3")
end