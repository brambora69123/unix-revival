return {
	AvatarThumbnail = "AvatarThumbnail",
	HeadShot = "HeadShot",
}
